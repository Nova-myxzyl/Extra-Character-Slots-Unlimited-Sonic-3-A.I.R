<img src="_img/thumbnail_media.png" align="center" /><br>

# Extra Character Slots - Unlimited

Extra Character Slots is a Framework that allows you to create Extra Characters,  with custom movesets, sprites, HUD, and etc., without replacing Sonic, Tails, or Knuckles.

## About "Unlimited" (v8.0) release

Extra Character Slots has changed for You. We have **completely rewritten** the original Lave sIime Framework, based on v7.35 work from iCloudius, for a better **User Experience**, new **Features**, **Stability and Improvements**. This is, *Extra Character Slots - Unlimited*, v8.0+.

## List of Features

\* Support for creating up to **255 Extra characters**.  
\* Custom **Act Select menu** for selecting Extra characters.  
\* Support for Extra characters **in Competition mode**.  
\* Support for Extra characters **in the Best Ending** screen.  
\* Support for Extra characters as an **Unlockable item**.  
\* Support for **Discord RPC** (Only for PC).  
\* Expanded  collection of **Guides and Documentation** for modders.  
\* **Clean and readable** framework code to researching.  
\* Integrated support with **D.A. Garden Edition**.

## Quick links

We have prepared for you a lot of tutorial material for every aspect of our Framework. We hope this will help you get organized faster!

[put some guides here]

More guides on GitHub Wiki's!

## Compatibility notes

\* **[Sonic 3 Complete Sound Test](https://gamebanana.com/mods/361615)** and any mod, that provides an Extra character, like **[Extra Slot Mighty](https://gamebanana.com/mods/336038)**, **[Extra Slot Ray](https://gamebanana.com/mods/403766)**, must be installed **above** this mod.   
\* **[extended level select](https://gamebanana.com/mods/54110)** must be installed **below** this mod.

## FAQ

**Q.  How to make a custom extra character?**  
A. Get a quick digression into Quick links, or go to the GitHub Wiki for additional guides.

**Q. Why don't my palettes work in the menu?**  
A. Characters with ID 3+ cannot work with palettes in the menu. Use for UI elements, and Best Ending screen, .png sprites instead of .bmp.

**Q. Why can't characters with ID 3+ work with palettes in the menu?**  
A. This is due to the fact that the built-in Sonic 3 A.I.R. palette address table cannot fit the palettes of all 255 characters. In other words, the addresses of the palettes of all characters with ID 3+ go beyond the built-in address table. There's nothing we can do about it.

**Q. I noticed a bug, where can I contact?**  
A. Contact me in the comments of Gamebanana, GitHub issues, or via Discord on the Sonic 3 A.I.R Community server. Try to describe the problem in more detail.